<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'yannchapil1');

/** MySQL database username */
define('DB_USER', 'yannchapil1');

/** MySQL database password */
define('DB_PASSWORD', 'Mamo1994');

/** MySQL hostname */
define('DB_HOST', 'yannchapil1.mysql.db');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '}Om6C!v,`P/Aczrp%Th 8I0R%Nq< W6v4q3]<EUKZZj^gZJ#7[#oS>H3u5OQFU+-');
define('SECURE_AUTH_KEY',  ']Dn5s1ceb~#,LL>&%Ci7rBDe~aHacAKz7fp85]vZJUMdSYtKwX7M]:_=?}Zdxc5u');
define('LOGGED_IN_KEY',    'Q#hZL8>6=xi#q?j-UhItbu.HkhD|K/07[6H+M7l:K!l|ptv;L6biq[bT*7Jy#q0A');
define('NONCE_KEY',        '7P$E2z;u[2x?^r4YZM7o_e[^x X=wK+,:%GQ-nF%+8|I!o6K-og b1[>Nc5r(Aj!');
define('AUTH_SALT',        '*~gcU~HDiG$Bjh_YkA|[h~+B1Pb|D2TW)[?,2~+: j2zS[i&[Xt#eR8mj]k,ceVi');
define('SECURE_AUTH_SALT', '5O~N0l%9Vsd|3>N=.+>o]&t|]jE/|}=U1p+fs#`51n9>GE6M TF;#3mJEt2FdpAz');
define('LOGGED_IN_SALT',   'Rcw-@5rm w%^nu:mfKN6a>+DfuP?n#-Ix<Ys@zv6L}PA:d/ccL:8#o)LeS;wHs2u');
define('NONCE_SALT',       '871No8KaeoC9RDPJltN|;<a,>`r6vIX~w9*-v=ed8|A;qMMrRBya9TFy<9>A@BAa');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpassoc_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
